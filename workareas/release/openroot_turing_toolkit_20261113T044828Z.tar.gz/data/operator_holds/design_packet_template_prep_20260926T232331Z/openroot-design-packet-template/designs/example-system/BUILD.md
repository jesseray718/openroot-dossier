# Build Procedure

## Preconditions

- [Required tools, workspace, PPE, and skill level]
- [Environmental or material constraints]

## Steps

1. [Step with measurable target]
2. [Step with inspection point]
3. [Step with safety checkpoint]

## Quality checks

- [Dimension/tolerance check]
- [Assembly integrity check]
- [Photograph or record required]

## Stop conditions

Stop and reassess if:

- [unsafe condition]
- [measurement outside expected range]
- [material defect]
