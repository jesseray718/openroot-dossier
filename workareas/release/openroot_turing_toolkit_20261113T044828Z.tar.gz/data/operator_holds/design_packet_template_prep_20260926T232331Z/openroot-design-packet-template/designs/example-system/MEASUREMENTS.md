# Measurements and Evidence

## Current status

No measurement exists yet. Do not infer performance from this template.

## Results table

| Test ID | Date | Input | Condition | Result | Unit | Uncertainty | Evidence reference |
|---|---|---|---|---|---|---|---|
| [test-id] | [UTC date] | [input] | [condition] | [result] | [unit] | [uncertainty] | [file/link/hash] |

## Interpretation

[Separate measured observations from interpretation.]

## Limitations

- [limitation]
- [unmeasured variable]

## Next test

[Smallest test that most reduces uncertainty.]
