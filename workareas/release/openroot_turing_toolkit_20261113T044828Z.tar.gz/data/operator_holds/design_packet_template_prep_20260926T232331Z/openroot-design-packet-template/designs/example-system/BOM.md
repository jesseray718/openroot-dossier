# Bill of Materials

| Item | Specification | Quantity | Source or substitute | Unit cost | Notes |
|---|---|---:|---|---:|---|
| [item] | [material/dimension/grade] | [quantity] | [source/substitute] | [cost] | [constraint] |

## Tooling

- [tool]
- [measurement instrument]
- [required safety equipment]

## Material assumptions

- [assumption]
