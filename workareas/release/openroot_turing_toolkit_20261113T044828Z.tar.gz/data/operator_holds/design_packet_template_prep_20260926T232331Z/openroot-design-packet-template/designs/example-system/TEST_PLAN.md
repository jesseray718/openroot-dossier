# Test Plan

## Question

[What claim or behavior is being tested?]

## Hypothesis

[State a falsifiable expectation.]

## Method

- Inputs: [inputs and units]
- Conditions: [ambient conditions, setup, duration]
- Instruments: [instrument and accuracy]
- Procedure: [numbered test sequence]
- Repetitions: [count]

## Acceptance criteria

- [criterion with units or observable condition]

## Failure criteria

- [unsafe result]
- [invalid measurement condition]
- [performance below stated threshold]

## Evidence to retain

- Raw measurements
- Photos or drawings of setup
- Calculation sheet or script revision
- Known uncertainty and deviations
