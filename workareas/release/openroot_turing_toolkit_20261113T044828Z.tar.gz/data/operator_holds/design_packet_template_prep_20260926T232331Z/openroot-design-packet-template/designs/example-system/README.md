# Example System

## Status

**Experimental template only.** This directory is a structure example, not a buildable device or performance claim.

## Purpose

[State the practical need and intended user.]

## System boundary

[State what this design includes and explicitly excludes.]

## Current maturity

- Claim level: Reference-only
- Build status: Not built
- Test status: Not tested
- Safety review: Not performed

## Packet contents

- [BOM](BOM.md)
- [Build procedure](BUILD.md)
- [Test plan](TEST_PLAN.md)
- [Measurements](MEASUREMENTS.md)
- [Safety boundary](SAFETY.md)
