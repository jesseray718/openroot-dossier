# Safety Boundary

## Hazards

| Hazard | Who or what is exposed | Control | Stop condition |
|---|---|---|---|
| [hazard] | [exposure] | [PPE/guard/procedure] | [condition] |

## Operating limits

- [temperature, pressure, electrical, structural, chemical, or tooling limit]
- [supervision requirement]
- [environmental limit]

## Not certified

This repository does not provide engineering certification, code compliance, medical advice, legal advice, or a substitute for qualified review where required.
