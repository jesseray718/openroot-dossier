## Purpose

## Packet files changed

## Evidence, tests, or measurements

## Safety and limitation changes

## Checklist

- [ ] No credentials, local databases, generated logs, or machine-specific runtime state included
- [ ] Claims are marked measured, buildable, experimental, or reference-only
- [ ] BOM, build, test, measurement, and safety impacts are addressed
- [ ] Publishing and release decisions remain human-gated
