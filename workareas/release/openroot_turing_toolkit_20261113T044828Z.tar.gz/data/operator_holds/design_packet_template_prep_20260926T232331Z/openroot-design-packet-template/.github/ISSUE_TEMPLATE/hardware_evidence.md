---
name: Hardware evidence report
about: Report a measurement, build result, failure, or correction
title: "[evidence] "
labels: evidence
---

## System and revision

## Claim being evaluated

## Materials, dimensions, and tools

## Conditions and procedure

## Measurements and units

## Evidence files or photographs

## Uncertainty and limitations

## Safety notes

## Recommended next test
