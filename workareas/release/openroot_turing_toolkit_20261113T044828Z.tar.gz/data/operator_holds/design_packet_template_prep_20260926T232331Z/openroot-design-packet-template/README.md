# OpenRoot Design-Packet Template

A reusable open-hardware and appropriate-technology repository template for turning a bounded concept into a buildable, testable, evidence-preserving public design packet.

Use this template for one physical system per repository: a material, thermal device, shelter element, water system, energy component, tool, or other appropriate-technology module.

## What a design packet contains

```text
need or hypothesis
→ constraints and safety boundary
→ design definition
→ BOM and dimensions
→ build procedure
→ test method
→ measured evidence
→ limitations and next iteration
```

A template is not certification. A repository made from this template must clearly distinguish **measured**, **buildable**, **experimental**, and **reference-only** material.

## Quick start

1. Use this repository as a template or copy its structure into a new focused project.
2. Rename `designs/example-system/` to the actual system identifier.
3. Replace every bracketed placeholder.
4. Remove example content before publishing a project-specific release.
5. Keep generated logs, local databases, credentials, personal notes, and machine-specific runtime state out of commits.

## Required project files

- `docs/DESIGN_PACKETS.md` — packet contract
- `docs/EVIDENCE_LEVELS.md` — claim/maturity vocabulary
- `docs/OPEN_HARDWARE_STATUS.md` — project-level status boundary
- `designs/<system>/README.md` — system overview and current status
- `designs/<system>/BOM.md` — bill of materials
- `designs/<system>/BUILD.md` — reproducible build procedure
- `designs/<system>/TEST_PLAN.md` — test method and acceptance criteria
- `designs/<system>/MEASUREMENTS.md` — results, uncertainty, and evidence
- `designs/<system>/SAFETY.md` — hazards, constraints, and operating limits

## License

This template currently carries the OpenRoot GPL-3.0-only software license. Before releasing a physical design, explicitly select and document appropriate licenses for code, documentation, drawings, CAD, and hardware design files.
