#!/usr/bin/env python3
"""registry_tsv_to_sqlite_v1.py — Auto Dossier Phase-4 bridge: TSV registry -> SQLite.

Loads one or more hash_registry_v1 TSVs into a SQLite database with:

  history  table  — append-only, every valid row ever loaded (the ledger view)
  files    table  — newest-wins per path (upsert keyed on path; a row only
                    replaces an older one if its scan_id is greater)
  duplicate_groups view — same sha256 in >1 distinct path, with reclaimable bytes

Standard library only (sqlite3). Bounded-batch writes; WAL journal.

LABELS: TESTED = sandbox fixture (see GATE_RECEIPT.txt). Fleet behavior = PROPOSED.

USAGE:
  registry_tsv_to_sqlite_v1.py --input REG.tsv [--input REG.tsv ...] --db OUT.sqlite3
                               [--batch 20000] [--rejects PATH] [--vacuum]
"""

import argparse
import os
import re
import sqlite3
import sys
import time

HEADER_PREFIX = "# hash_registry_v1"
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
COLS = ("sha256", "size", "mtime", "path", "root", "host", "scan_id")

SCHEMA = """
CREATE TABLE IF NOT EXISTS history (
    sha256  TEXT NOT NULL,
    size    INTEGER NOT NULL,
    mtime   INTEGER NOT NULL,
    path    TEXT NOT NULL,
    root    TEXT NOT NULL,
    host    TEXT NOT NULL,
    scan_id TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS files (
    sha256  TEXT NOT NULL,
    size    INTEGER NOT NULL,
    mtime   INTEGER NOT NULL,
    path    TEXT PRIMARY KEY,
    root    TEXT NOT NULL,
    host    TEXT NOT NULL,
    scan_id TEXT NOT NULL
);
CREATE VIEW IF NOT EXISTS duplicate_groups AS
    SELECT sha256,
           COUNT(*)                 AS copies,
           SUM(size)                AS total_bytes,
           SUM(size) - MIN(size)    AS reclaimable_bytes
    FROM files
    GROUP BY sha256
    HAVING COUNT(*) > 1;
"""

UPSERT_FILES = """
INSERT INTO files (sha256, size, mtime, path, root, host, scan_id)
VALUES (?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(path) DO UPDATE SET
    sha256  = excluded.sha256,
    size    = excluded.size,
    mtime   = excluded.mtime,
    root    = excluded.root,
    host    = excluded.host,
    scan_id = excluded.scan_id
WHERE excluded.scan_id > files.scan_id
"""


def parse_args():
    ap = argparse.ArgumentParser(description="Load hash_registry_v1 TSVs into SQLite.")
    ap.add_argument("--input", action="append", required=True, help="registry TSV (repeatable)")
    ap.add_argument("--db", required=True, help="output SQLite database path")
    ap.add_argument("--batch", type=int, default=20000, help="rows per transaction (default 20000)")
    ap.add_argument("--rejects", help="where to write rejected rows (default <db>.rejected.tsv)")
    ap.add_argument("--vacuum", action="store_true", help="VACUUM ANALYZE after load")
    return ap.parse_args()


def valid_row(parts):
    if len(parts) != 7:
        return False
    sha, size, mtime, path, root, host, scan_id = parts
    return (
        SHA_RE.match(sha) is not None
        and size.isdigit()
        and mtime.isdigit()
        and all(x != "" for x in (path, root, host, scan_id))
    )


def main():
    args = parse_args()

    if tuple(int(x) for x in sqlite3.sqlite_version.split(".")) < (3, 24, 0):
        sys.exit(f"FATAL: sqlite {sqlite3.sqlite_version} is too old for upsert (need >= 3.24.0)")

    for f in args.input:
        if not os.path.isfile(f):
            sys.exit(f"FATAL: input not found: {f}")

    rejects_path = args.rejects or args.db + ".rejected.tsv"
    t0 = time.time()
    n_hist = n_files_written = n_rejects = 0

    con = sqlite3.connect(args.db)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.executescript(SCHEMA)

    hist_batch, files_batch = [], []
    rej = open(rejects_path, "w", encoding="utf-8")

    def flush():
        nonlocal n_hist, n_files_written
        if hist_batch:
            con.executemany(
                "INSERT INTO history (sha256,size,mtime,path,root,host,scan_id) VALUES (?,?,?,?,?,?,?)",
                hist_batch,
            )
            n_hist += len(hist_batch)
            hist_batch.clear()
        if files_batch:
            con.executemany(UPSERT_FILES, files_batch)
            n_files_written += len(files_batch)
            files_batch.clear()
        con.commit()

    for path in args.input:
        with open(path, "r", encoding="utf-8", errors="surrogateescape") as fh:
            first = fh.readline()
            if not first.startswith(HEADER_PREFIX):
                sys.exit(
                    f"FATAL: {path} does not carry the '{HEADER_PREFIX}' header — refusing to guess columns."
                )
            for lineno, line in enumerate(fh, start=2):
                line = line.rstrip("\n")
                if not line:
                    continue
                parts = line.split("\t")
                if not valid_row(parts):
                    rej.write(f"{path}:{lineno}\t{line}\n")
                    n_rejects += 1
                    continue
                sha, size, mtime, fpath, root, host, scan_id = parts
                row = (sha, int(size), int(mtime), fpath, root, host, scan_id)
                hist_batch.append(row)
                files_batch.append(row)
                if len(hist_batch) >= args.batch:
                    flush()
    flush()
    rej.close()

    con.execute("CREATE INDEX IF NOT EXISTS idx_files_sha ON files(sha256)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_history_sha ON history(sha256)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_history_path ON history(path)")
    if args.vacuum:
        con.execute("ANALYZE")
        con.execute("VACUUM")

    files_rows = con.execute("SELECT COUNT(*) FROM files").fetchone()[0]
    distinct_sha = con.execute("SELECT COUNT(DISTINCT sha256) FROM files").fetchone()[0]
    dup_groups = con.execute("SELECT COUNT(*) FROM duplicate_groups").fetchone()[0]
    reclaimable = con.execute(
        "SELECT COALESCE(SUM(reclaimable_bytes), 0) FROM duplicate_groups"
    ).fetchone()[0]
    total_bytes = con.execute("SELECT COALESCE(SUM(size), 0) FROM files").fetchone()[0]
    con.close()

    el = time.time() - t0
    def human(b):
        for u in ("B", "KiB", "MiB", "GiB", "TiB"):
            if b < 1024 or u == "TiB":
                return f"{b:.1f} {u}"
            b /= 1024

    print("RECEIPT registry_tsv_to_sqlite_v1")
    print(f"  db={args.db} sqlite={sqlite3.sqlite_version} elapsed_s={el:.1f}")
    print(f"  inputs={len(args.input)} history_rows={n_hist} files_rows={files_rows}")
    print(f"  upsert_writes={n_files_written} rejected={n_rejects} rejects_file={rejects_path}")
    print(f"  distinct_sha256={distinct_sha} total_bytes={total_bytes} ({human(total_bytes)})")
    print(f"  duplicate_groups={dup_groups} reclaimable={reclaimable} ({human(reclaimable)})")
    print("  LABELS: counts OBSERVED for the given input files only — not fleet claims.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
