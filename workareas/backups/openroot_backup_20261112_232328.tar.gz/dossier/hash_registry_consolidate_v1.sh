#!/usr/bin/env bash
# hash_registry_consolidate_v1.sh — Auto Dossier Phase 1: registry consolidator.
#
# WHAT IT DOES
#   1. Validates every input registry (strict TSV check; malformed rows are
#      quarantined to rows_rejected.tsv — never silently dropped).
#   2. Merges inputs, newest-wins per path (greatest scan_id), constant memory
#      (streaming sort — safe on multi-GB registries).
#   3. Computes duplicate groups (same sha256, distinct paths) and reclaimable
#      bytes (group bytes minus one retained copy).
#
# INPUT FORMAT: same as hash_keeper_v1.sh writes — first line
#   '# hash_registry_v1 ...' header, then 7-column TSV rows.
#   NOTE: census_manifest.tsv (fleet census format) is NOT a v1 input.
#
# OUTPUTS (in --outdir):
#   registry_consolidated.tsv   newest row per path = current filesystem state
#   rows_rejected.tsv           malformed rows quarantined (may be empty)
#   duplicate_groups.tsv        sha256 <TAB> copies <TAB> total_bytes <TAB> reclaimable_bytes <TAB> example_path
#   duplicate_paths.tsv         sha256 <TAB> path <TAB> size  (full detail)
#   CONSOLIDATION_RECEIPT.md    counts, inputs + their sha256s, human summary
#
# LABELS: TESTED = sandbox fixture (see GATE_RECEIPT.txt). Fleet behavior = PROPOSED.
#
# USAGE:
#   hash_registry_consolidate_v1.sh --input REG.tsv [--input REG.tsv ...]
#                                   --outdir DIR [--force]
set -u -o pipefail

TOOL="hash_registry_consolidate_v1"
VERSION="1"

usage() { awk 'NR>1 && /^#/{sub(/^# ?/,"");print} /^$/{exit}' "$0"; exit "${1:-0}"; }

INPUTS=(); OUTDIR=""; FORCE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --input)  INPUTS+=("${2:?--input needs a value}"); shift 2 ;;
    --outdir) OUTDIR="$2"; shift 2 ;;
    --force)  FORCE=1; shift ;;
    -h|--help) usage 0 ;;
    *) echo "FATAL: unknown argument: $1" >&2; usage 1 ;;
  esac
done
[ "${#INPUTS[@]}" -ge 1 ] && [ -n "$OUTDIR" ] || { echo "FATAL: need >=1 --input and --outdir" >&2; usage 1; }

T0=$SECONDS
for f in "${INPUTS[@]}"; do
  [ -r "$f" ] || { echo "FATAL: input not readable: $f" >&2; exit 2; }
  head -n 1 -- "$f" | grep -q '^# hash_registry_v1' || {
    echo "FATAL: $f does not carry the '# hash_registry_v1' header — refusing to guess columns." >&2
    exit 2
  }
done

if [ -e "$OUTDIR" ] && [ "$FORCE" -ne 1 ]; then
  echo "FATAL: outdir exists: $OUTDIR (append-only culture: pass --force to replace a FAILED attempt)" >&2
  exit 2
fi
mkdir -p -- "$OUTDIR"

TMPD="$(mktemp -d "${TMPDIR:-/tmp}/consolidate.XXXXXX")" || exit 3
trap 'rm -rf -- "$TMPD" 2>/dev/null || true' EXIT

# ---------------------------------------------------------- 0. input hashes --
HASHLIST="$TMPD/input_hashes.txt"
: > "$HASHLIST"
for f in "${INPUTS[@]}"; do sha256sum -- "$f" >> "$HASHLIST"; done

# --------------------------------------------------------- 1. validate rows --
VALID="$TMPD/valid.tsv"
REJ="$OUTDIR/rows_rejected.tsv"
: > "$REJ"
for f in "${INPUTS[@]}"; do
  awk -F'\t' -v rej="$REJ" '
    /^#/ { next }
    {
      ok = (NF==7) \
        && (length($1)==64) && ($1 !~ /[^0-9a-f]/) \
        && ($2 ~ /^[0-9]+$/) && ($3 ~ /^[0-9]+$/) \
        && ($4!="") && ($5!="") && ($6!="") && ($7!="")
      if (ok) print; else print >> rej
    }
  ' "$f" >> "$VALID"
done

ROWS_IN=$(wc -l < "$VALID")
ROWS_REJ=$(wc -l < "$REJ")
[ "$ROWS_IN" -gt 0 ] || { echo "FATAL: zero valid rows across all inputs — nothing to do." >&2; exit 4; }

# ------------------------------------- 2. newest-wins per path (streaming)  --
# sort by path (k4) then scan_id (k7), ascending; last row per path wins.
CONSOL="$OUTDIR/registry_consolidated.tsv"
head -n 1 -- "${INPUTS[0]}" > "$CONSOL"
LC_ALL=C sort -t$'\t' -k4,4 -k7,7 "$VALID" \
  | awk -F'\t' '
      { if ($4 != cur) { if (cur != "") print prev; cur = $4 } prev = $0 }
      END { if (cur != "") print prev }
    ' >> "$CONSOL"
PATHS_UNIQ=$(($(wc -l < "$CONSOL") - 1))

# ------------------------------------------------ 3. duplicate groups (dups) --
SORTED="$TMPD/consol_sorted.tsv"
LC_ALL=C sort -t$'\t' -k1,1 "$CONSOL" > "$SORTED"   # header row sorts to top ('#'<hex), skipped below

DUPFILE="$OUTDIR/duplicate_groups.tsv"
DETAIL="$OUTDIR/duplicate_paths.tsv"
STATS="$TMPD/groupstats.txt"
# NOTE: never name a bash var GROUPS — it is a special built-in array (the
# process's group list); assignments are silently discarded (bit us once).
printf 'sha256\tcopies\ttotal_bytes\treclaimable_bytes\texample_path\n' > "$DUPFILE"
printf 'sha256\tpath\tsize\n' > "$DETAIL"

LC_ALL=C awk -F'\t' -v groups="$DUPFILE" -v detail="$DETAIL" -v stats="$STATS" '
  /^#/ { next }
  function flushg() {
    if (cur == "") return
    if (n >= 2) {
      gc++
      dfc += n
      rec = sum - sz1
      printf "%s\t%d\t%d\t%d\t%s\n", cur, n, sum, rec, p1 >> groups
    } else {
      u1++
    }
  }
  {
    if ($1 != cur) { flushg(); cur = $1; n = 0; sum = 0; sz1 = $2; p1 = $4 }
    n++; sum += $2
    printf "%s\t%s\t%s\n", $1, $4, $2 > detail
  }
  END {
    flushg()
    printf "dup_groups=%d\ndup_files=%d\nsingle_copy_hashes=%d\n", gc, dfc, u1 > stats
  }
' "$SORTED"

dup_groups=0; dup_files=0; single_hashes=0
if [ -f "$STATS" ]; then
  while IFS='=' read -r k v; do
    case "$k" in
      dup_groups)         dup_groups="$v" ;;
      dup_files)          dup_files="$v" ;;
      single_copy_hashes) single_hashes="$v" ;;
    esac
  done < "$STATS"
fi

RECLAIM=$(awk -F'\t' 'NR>1 { s += $4 } END { print s+0 }' "$DUPFILE")
TOTAL_BYTES=$(awk -F'\t' 'NR>1 { s += $2 } END { print s+0 }' "$CONSOL")

# ---------------------------------------------------------------- 4. receipt --
human() {  # bytes -> human, numfmt if present else awk fallback
  if command -v numfmt >/dev/null 2>&1; then numfmt --to=iec -- "$1" 2>/dev/null || echo "${1} B"
  else awk -v b="$1" 'BEGIN{s="B KiB MiB GiB TiB";split(s,u," ");i=1;while(b>=1024&&i<5){b/=1024;i++}printf "%.1f %s",b,u[i]}'
  fi
}
ELAPSED=$(( SECONDS - T0 ))
RCPT="$OUTDIR/CONSOLIDATION_RECEIPT.md"
{
  printf '# CONSOLIDATION RECEIPT — %s v%s\n\n' "$TOOL" "$VERSION"
  printf 'status=COMPLETE elapsed_s=%d\n\n' "$ELAPSED"
  printf '## Inputs (sha256 OBSERVED at consolidation time)\n\n'
  printf '```\n'; cat "$HASHLIST"; printf '```\n\n'
  printf '## Counts\n\n'
  printf '| metric | value |\n|---|---|\n'
  printf '| input rows (valid) | %s |\n' "$ROWS_IN"
  printf '| input rows (rejected/quarantined) | %s |\n' "$ROWS_REJ"
  printf '| unique paths (consolidated) | %s |\n' "$PATHS_UNIQ"
  printf '| total bytes under unique paths | %s (%s) |\n' "$TOTAL_BYTES" "$(human "$TOTAL_BYTES")"
  printf '| distinct sha256 (single-copy hashes) | %s |\n' "${single_hashes:-0}"
  printf '| duplicate groups | %s |\n' "${dup_groups:-0}"
  printf '| files in duplicate groups | %s |\n' "${dup_files:-0}"
  printf '| reclaimable bytes | %s (%s) |\n' "${RECLAIM:-0}" "$(human "${RECLAIM:-0}")"
  printf '\n## Method\n\n'
  printf -- '- Validate strict (7 cols, 64-hex sha256, numeric size/mtime, non-empty fields); malformed rows quarantined, never dropped silently.\n'
  printf -- '- Newest-wins per path by lexicographic max scan_id (HK-<ts>.<ms>Z-<host> is fixed-width, so it sorts chronologically).\n'
  printf -- '- Duplicate groups: identical sha256 across distinct paths; reclaimable = group bytes minus one retained copy.\n'
  printf -- '- Streaming sort throughout; constant memory; safe for multi-GB registries.\n\n'
  printf -- 'LABELS: all numbers above are OBSERVED for this consolidation run only — they describe the INPUT FILES given, not any live node.\n'
} > "$RCPT"

printf 'CONSOLIDATED rows_in=%s rejected=%s paths=%s dup_groups=%s reclaimable=%s receipt=%s\n' \
  "$ROWS_IN" "$ROWS_REJ" "$PATHS_UNIQ" "${dup_groups:-0}" "$RECLAIM" "$RCPT"
exit 0
