#!/usr/bin/env bash
# =============================================================================
# release_push_v1.sh — AUTO DOSSIER RELEASE RAIL (v1)
#
# WHAT IT DOES (in order)
#   1. Assembles the payload: copies sibling *.sh *.py *.md (+ docs/*.md) from
#      this script's directory into --repo-dir (default $HOME/openroot/dossier).
#      It reads nothing outside its own directory.
#   2. GATES every payload file before anything is committed:
#          *.sh -> bash -n            *.py -> python3 -m py_compile
#      Any FAIL aborts the release. Receipt: GATE_RECEIPT.txt
#   3. Writes BUILD_STATUS.md (file table + sha256) — the build status that
#      gets committed and pushed.
#   4. git: init if needed -> commit -> annotated tag v<UTCdate>-<shortsha>
#      (auto-uniquified -r2, -r3 ... when the tag already exists).
#   5. Pushes branch + tag. If origin is absent, creates the GitHub repo via
#      gh (PRIVATE by default; --public to flip) and wires the remote.
#   6. Creates the GitHub release for the tag with every payload file plus all
#      receipts as release assets (gh release create / upload --clobber).
#   7. Writes RELEASE_RECEIPT.txt, appends one line to WORK_LOG.md
#      (append-only), then commits and pushes that as the "log:" commit.
#
# REQUIRES
#   git + sha256sum always. For push/release: gh CLI authenticated
#   (`gh auth login` once) and network. python3 only if .py files are present.
#
# USAGE (ready-to-run as-is; every flag optional)
#   bash release_push_v1.sh                        # private repo openroot-dossier
#   bash release_push_v1.sh --repo my-name         # choose repo name
#   bash release_push_v1.sh --public --tag v0.1.0  # public repo + fixed tag
#   bash release_push_v1.sh --no-push              # gate+status+commit+tag, local only
#   bash release_push_v1.sh --dry-run              # print plan; gates run for real
#
# FILES IT WRITES (inside --repo-dir)
#   GATE_RECEIPT.txt  BUILD_STATUS.md  RELEASE_NOTES.md  RELEASE_RECEIPT.txt
#   WORK_LOG.md (append-only)  .gitignore  dist/ (release-asset staging)
#
# DOCTRINE
#   BUILD_STATUS.md is a live gauge, regenerated every build. WORK_LOG.md is
#   append-only history: lines are added, never edited or removed.
#
# LABELS
#   TESTED   — --no-push path end-to-end in sandbox (gate, status, commit, tag,
#              receipts, tag-uniquifier) plus --dry-run plan output.
#   PROPOSED — gh push / repo-create / release path (sandbox has no gh or
#              network auth); the first node run must append its WORK_LOG line.
# =============================================================================

set -eu -o pipefail
umask 022

if [ -z "${BASH_VERSION:-}" ]; then
  echo "FATAL: run with bash: bash $0 $*" >&2
  exit 2
fi

TOOL="release_push_v1"
VERSION="1"

usage() { awk '/^# ====/{n++; next} n==1{sub(/^# ?/,""); print} n>=2{exit}' "$0"; exit "${1:-0}"; }

# ---------------------------------------------------------------- arguments --
REPO_DIR=""
REPO_NAME="${GH_REPO_NAME:-openroot-dossier}"
TAG=""
VISIBILITY="private"
PUSH=1
DRY=0

while [ $# -gt 0 ]; do
  case "$1" in
    --repo-dir) REPO_DIR="${2:?--repo-dir needs a value}"; shift 2 ;;
    --repo)     REPO_NAME="${2:?--repo needs a value}"; shift 2 ;;
    --tag)      TAG="${2:?--tag needs a value}"; shift 2 ;;
    --public)   VISIBILITY="public"; shift ;;
    --private)  VISIBILITY="private"; shift ;;
    --no-push)  PUSH=0; shift ;;
    --dry-run)  DRY=1; shift ;;
    -h|--help)  usage 0 ;;
    *) echo "FATAL: unknown argument: $1" >&2; usage 1 ;;
  esac
done

# ------------------------------------------------------------- dependencies --
for t in git sha256sum; do
  command -v "$t" >/dev/null 2>&1 || { echo "FATAL: missing dependency: $t" >&2; exit 2; }
done

GH_USER=""
if [ "$DRY" -eq 0 ]; then
  if [ "$PUSH" -eq 1 ]; then
    command -v gh >/dev/null 2>&1 || {
      echo "FATAL: missing dependency: gh (https://cli.github.com) — or rerun with --no-push" >&2
      exit 2
    }
    gh auth status >/dev/null 2>&1 || { echo "FATAL: gh is not authenticated — run: gh auth login" >&2; exit 2; }
    GH_USER="$(gh api user -q .login)" || { echo "FATAL: 'gh api user' failed" >&2; exit 2; }
  fi
else
  if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
    GH_USER="$(gh api user -q .login 2>/dev/null || true)"
  fi
fi

say() { printf '%s\n' "$*"; }
run() { if [ "$DRY" -eq 1 ]; then printf '  [DRY] %s\n' "$*"; else "$@"; fi; }

# ----------------------------------------------------------- stage payload ---
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
[ -n "$REPO_DIR" ] || REPO_DIR="$HOME/openroot/dossier"
mkdir -p -- "$REPO_DIR"
REPO_DIR="$(cd -- "$REPO_DIR" && pwd)"

STAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
say "== ${TOOL} v${VERSION}  (${STAMP})"
say "   script_dir: ${SCRIPT_DIR}"
say "   repo_dir  : ${REPO_DIR}"
say "   repo      : ${GH_USER:-<local-only>}/${REPO_NAME} (${VISIBILITY})  push=${PUSH} dry_run=${DRY}"

if [ "$SCRIPT_DIR" != "$REPO_DIR" ]; then
  copied=0
  for f in "$SCRIPT_DIR"/*.sh "$SCRIPT_DIR"/*.py "$SCRIPT_DIR"/*.md; do
    [ -e "$f" ] || continue
    cp -f -- "$f" "$REPO_DIR/"
    copied=$((copied + 1))
  done
  if [ -d "$SCRIPT_DIR/docs" ]; then
    mkdir -p -- "$REPO_DIR/docs"
    for f in "$SCRIPT_DIR/docs"/*.md; do
      [ -e "$f" ] || continue
      cp -f -- "$f" "$REPO_DIR/docs/"
      copied=$((copied + 1))
    done
  fi
  say "   payload   : copied ${copied} file(s)"
else
  say "   payload   : script lives inside repo dir — gating in place"
fi
cd -- "$REPO_DIR"

# ------------------------------------------------------------------- gate ----
GATE_OK=1
SH_N=0
PY_N=0
: > gate_stderr.tmp
{
  printf '# GATE RECEIPT — %s v%s\n' "$TOOL" "$VERSION"
  printf 'sealed_utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  printf 'host=%s\n' "$(uname -srmo 2>/dev/null || uname -a)"
  printf 'repo_dir=%s\n\n' "$REPO_DIR"
  printf '| file | gate | sha256 |\n'
  printf '|---|---|---|\n'
} > GATE_RECEIPT.txt

for f in ./*.sh; do
  [ -e "$f" ] || { echo "FATAL: no .sh files found in $REPO_DIR" >&2; exit 4; }
  if bash -n "$f" 2>>gate_stderr.tmp; then g="PASS"; else g="FAIL"; GATE_OK=0; fi
  h="$(sha256sum -- "$f" | cut -d ' ' -f1)"
  printf '| %s | bash -n: %s | %s |\n' "${f#./}" "$g" "$h" >> GATE_RECEIPT.txt
  say "   gate ${g}  bash -n     ${f#./}"
  SH_N=$((SH_N + 1))
done

if command -v python3 >/dev/null 2>&1; then
  for f in ./*.py; do
    [ -e "$f" ] || break
    if PYTHONPYCACHEPREFIX="$PWD/.pycache_gate" python3 -m py_compile "$f" 2>>gate_stderr.tmp; then
      g="PASS"
    else
      g="FAIL"
      GATE_OK=0
    fi
    h="$(sha256sum -- "$f" | cut -d ' ' -f1)"
    printf '| %s | py_compile: %s | %s |\n' "${f#./}" "$g" "$h" >> GATE_RECEIPT.txt
    say "   gate ${g}  py_compile  ${f#./}"
    PY_N=$((PY_N + 1))
  done
fi

if [ "$GATE_OK" -eq 1 ]; then
  rm -f -- gate_stderr.tmp
  rm -rf -- .pycache_gate
else
  say "FATAL: GATE FAILED — refusing to commit/push/release. Evidence: ${REPO_DIR}/gate_stderr.tmp" >&2
  exit 4
fi

# --------------------------------------------------------- build status ------
{
  printf '# BUILD STATUS\n\n'
  printf -- '- generated_utc: %s\n' "$STAMP"
  printf -- '- host: %s\n' "$(uname -srmo 2>/dev/null || uname -a)"
  printf -- '- gh_user: %s\n' "${GH_USER:-n/a (local-only build)}"
  printf -- '- target_repo: %s (%s)\n' "$REPO_NAME" "$VISIBILITY"
  printf -- '- push=%s dry_run=%s\n' "$PUSH" "$DRY"
  printf -- '- gate: PASS (see GATE_RECEIPT.txt)\n'
  printf -- '- note: BUILD_STATUS.md is a live gauge, regenerated every build; WORK_LOG.md is the append-only history.\n\n'
  printf '| payload file | bytes | sha256 |\n'
  printf '|---|---|---|\n'
} > BUILD_STATUS.md

for f in ./*.sh ./*.py ./*.md ./docs/*.md; do
  [ -e "$f" ] || continue
  case "${f#./}" in
    BUILD_STATUS.md) continue ;;
  esac
  printf '| %s | %s | %s |\n' \
    "${f#./}" "$(wc -c < "$f" | tr -d ' ')" "$(sha256sum -- "$f" | cut -d ' ' -f1)" >> BUILD_STATUS.md
done
say "   status    : BUILD_STATUS.md written"

# -------------------------------------------------------------------- git ----
if [ ! -e .git ]; then
  # -c init.defaultBranch=main silences the hint and names the branch on git
  # >= 2.28; symbolic-ref below covers older git and is a no-op otherwise.
  run git -c init.defaultBranch=main init -q
  run git symbolic-ref HEAD refs/heads/main
fi
# symbolic-ref first: on an unborn HEAD `rev-parse --abbrev-ref` prints "HEAD"
# plus a hint to stderr and would poison the variable with a newline.
BRANCH="$(git symbolic-ref --short HEAD 2>/dev/null || git rev-parse --abbrev-ref HEAD 2>/dev/null || echo main)"
if [ -z "$BRANCH" ] || [ "$BRANCH" = "HEAD" ]; then
  echo "FATAL: repo is in detached-HEAD state — 'git checkout <branch>' first, or pass --repo-dir at a branch." >&2
  exit 2
fi

if [ "$DRY" -eq 0 ]; then
  if [ -z "$(git config user.name 2>/dev/null || true)" ]; then
    git config user.name "${GH_USER:-openroot}"
  fi
  if [ -z "$(git config user.email 2>/dev/null || true)" ]; then
    if [ -n "$GH_USER" ]; then
      git config user.email "${GH_USER}@users.noreply.github.com"
    else
      git config user.email "openroot@localhost"
    fi
  fi
fi

cat > .gitignore <<'EOF'
__pycache__/
.pycache_gate/
dist/
gate_stderr.tmp
*.sqlite3
*.sqlite3-wal
*.sqlite3-shm
registry_*.tsv
*.tsv.receipts.log
EOF

run git add -A
run git commit -m "build: gate PASS — build status + receipts ${STAMP}" --allow-empty
say "   git       : build status committed (branch: ${BRANCH})"

# -------------------------------------------------------------------- tag ----
if [ -z "$TAG" ]; then
  HEAD_SHORT="$(git rev-parse --short HEAD 2>/dev/null || echo none)"
  TAG="v$(date -u +%Y%m%d)-${HEAD_SHORT}"
fi
tn=2
BASE_TAG="$TAG"
while git rev-parse -q --verify "refs/tags/${TAG}" >/dev/null 2>&1; do
  TAG="${BASE_TAG}-r${tn}"
  tn=$((tn + 1))
done
run git tag -a "$TAG" -m "release ${TAG} — gate PASS ${STAMP}"
say "   tag       : ${TAG}"

# ------------------------------------------------------------ push + release -
REL_URL=""
if [ "$PUSH" -eq 1 ]; then
  if git remote get-url origin >/dev/null 2>&1; then
    say "   origin    : $(git remote get-url origin)"
  elif [ "$DRY" -eq 1 ]; then
    say "  [DRY] gh repo create ${REPO_NAME} --${VISIBILITY} + git remote add origin"
  else
    if gh repo view "${GH_USER}/${REPO_NAME}" >/dev/null 2>&1; then
      say "   github    : repo exists — ${GH_USER}/${REPO_NAME}"
    else
      say "   github    : creating repo ${GH_USER}/${REPO_NAME} (${VISIBILITY})"
      gh repo create "$REPO_NAME" "--${VISIBILITY}" \
        --description "Auto Dossier build bundle — hash registry Phase 1 + release rail"
    fi
    git remote add origin "https://github.com/${GH_USER}/${REPO_NAME}.git"
  fi

  run gh auth setup-git
  run git push -u origin "$BRANCH"
  run git push origin "$TAG"

  {
    printf '# Release %s\n\n' "$TAG"
    printf -- '- branch: %s   head: %s\n' "$BRANCH" "$(git rev-parse --short HEAD 2>/dev/null || echo n/a)"
    printf -- '- gate: every .sh passed bash -n; every .py passed py_compile — see GATE_RECEIPT.txt\n'
    printf -- '- append-only doctrine: BUILD_STATUS.md = live gauge; WORK_LOG.md = history\n\n'
    printf '## Build status\n\n'
    cat BUILD_STATUS.md
    printf '\n## Gate receipt\n\n'
    cat GATE_RECEIPT.txt
  } > RELEASE_NOTES.md

  mkdir -p dist
  if [ -d docs ]; then mkdir -p dist/docs; fi
  for f in ./*.sh ./*.py ./*.md ./docs/*.md; do
    [ -e "$f" ] || continue
    cp -f -- "$f" "dist/${f#./}"
  done

  if [ "$DRY" -eq 1 ]; then
    say "  [DRY] gh release create ${TAG} dist/* --title \"${REPO_NAME} ${TAG}\" --notes-file RELEASE_NOTES.md"
    REL_URL="https://github.com/${GH_USER:-USER}/${REPO_NAME}/releases/tag/${TAG} (dry-run estimate)"
  else
    if gh release view "$TAG" >/dev/null 2>&1; then
      say "   release   : exists — uploading assets with --clobber"
      gh release upload "$TAG" dist/* --clobber
    else
      say "   release   : creating"
      gh release create "$TAG" dist/* \
        --title "${REPO_NAME} ${TAG}" \
        --notes-file RELEASE_NOTES.md
    fi
    REL_URL="$(gh release view "$TAG" --json url -q .url 2>/dev/null || true)"
  fi
fi

# ------------------------------------------------- receipt + append-only log -
HEAD_SHORT="$(git rev-parse --short HEAD 2>/dev/null || echo none)"
NOW="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
{
  printf '# RELEASE RECEIPT — %s v%s\n\n' "$TOOL" "$VERSION"
  printf -- '- when_utc: %s\n' "$NOW"
  printf -- '- repo: %s/%s (%s)\n' "${GH_USER:-local}" "$REPO_NAME" "$VISIBILITY"
  printf -- '- url: %s\n' "${REL_URL:-n/a (--no-push or dry-run)}"
  printf -- '- branch: %s   head: %s   tag: %s\n' "$BRANCH" "$HEAD_SHORT" "$TAG"
  printf -- '- gate: PASS (%d sh, %d py files)\n' "$SH_N" "$PY_N"
  printf -- '- assets: dist/ (payload + receipts)\n'
  printf -- '- next: paste the new WORK_LOG.md line into the master manifest (§7, append-only)\n'
} > RELEASE_RECEIPT.txt

WORKLOG="$REPO_DIR/WORK_LOG.md"
if [ ! -e "$WORKLOG" ]; then
  printf '# WORK LOG — %s (append-only; newest at bottom)\n\n| when_utc | event | detail |\n|---|---|---|\n' \
    "$REPO_NAME" >> "$WORKLOG"
fi
printf '| %s | release | tag=%s repo=%s/%s head=%s gate=PASS sh=%d py=%d url=%s |\n' \
  "$NOW" "$TAG" "${GH_USER:-local}" "$REPO_NAME" "$HEAD_SHORT" "$SH_N" "$PY_N" \
  "${REL_URL:-local-only}" >> "$WORKLOG"

run git add -A
run git commit -m "log: release receipt ${TAG}"
if [ "$PUSH" -eq 1 ] && [ "$DRY" -eq 0 ]; then
  git push origin "$BRANCH"
fi

say "== DONE"
say "   tag       : ${TAG}"
say "   release   : ${REL_URL:-n/a (--no-push or dry-run)}"
say "   receipt   : ${REPO_DIR}/RELEASE_RECEIPT.txt"
say "   work_log  : ${REPO_DIR}/WORK_LOG.md (one append-only line added)"
