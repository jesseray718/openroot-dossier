# Cloud Cascade v1 — tier ladder, router, quota cron (manifest §1.5, §1.7)

Status: PROPOSED (design sketch 2026-11-09, not implemented). Canonical pipeline:
**Classify → Authorize → Select → Schedule** (§1.7). All quota numbers below are
deliberately `TBD: verify current published limits` — they change constantly; the
whole point of the daily recalibration cron is that nothing hard-codes them.

## 1. Tier ladder

```
Tier 0  free/nearly-free   Gemini free tier · Groq free tier · Ollama Cloud free models · local Ollama
Tier 1  cheap task-specific   small paid models for narrow jobs (embed, classify, extract)
Tier 2  frontier elite        hardest questions only; difficulty gate must say so
```

Routing rule: exhaust Tier 0 remaining quota → Tier 1 → Tier 2. Difficulty/complexity
determiner picks the MINIMUM tier that can plausibly answer (never the reverse).

## 2. Provider config sketch (`cascade_config.json`)

```json
{
  "version": "cascade_v1",
  "tiers": [
    { "id": 0, "providers": [
      { "name": "gemini-free",   "kinds": ["chat","embed"], "rpm": "TBD", "rpd": "TBD",
        "key_env": "GEMINI_API_KEY", "probe": "1-token chat", "cost": 0 },
      { "name": "groq-free",     "kinds": ["chat"],         "rpm": "TBD", "rpd": "TBD",
        "key_env": "GROQ_API_KEY",   "probe": "1-token chat", "cost": 0 },
      { "name": "ollama-cloud-free", "kinds": ["chat","embed"], "rpm": "TBD", "rpd": "TBD",
        "key_env": "OLLAMA_CLOUD_KEY", "probe": "1-token chat", "cost": 0 },
      { "name": "ollama-local",  "kinds": ["chat","embed"], "rpm": null, "rpd": null,
        "key_env": null,             "probe": null,           "cost": 0, "always_last_in_tier": true }
    ]},
    { "id": 1, "providers": [ { "name": "PROPOSED-cheap-embed", "kinds": ["embed"],
        "rpm": "TBD", "rpd": null, "key_env": "CHEAP_EMBED_KEY", "cost": "TBD" } ]},
    { "id": 2, "providers": [ { "name": "PROPOSED-frontier", "kinds": ["chat"],
        "rpm": "TBD", "rpd": null, "key_env": "FRONTIER_KEY", "cost": "TBD" } ]}
  ],
  "quota_cron":   { "kind": "cron", "expr": "5 0 * * *", "tz": "America/Chicago",
                    "action": "probe_each_provider_1token -> write quota_state.json" },
  "state_file":   "quota_state.json",
  "difficulty_determiner": {
    "inputs": ["token_estimate", "primitive_chain_length", "citation_density",
               "loop_count_so_far"],
    "output": "tier_hint  (0|1|2)",
    "note": "growable at near-zero marginal cost; start with 3 heuristics, add per receipts"
  }
}
```

Key hygiene: keys live in the environment or `data/api_keys.db` — **never committed**
(standing queue rule). The config file holds only `key_env` NAMES.

## 3. Router pipeline (primitives per §1.7)

1. **Classify** — question type + complexity → `tier_hint` + required kinds
   (chat/embed/vision).
2. **Authorize** — provider usable? key present (Authorize), quota remaining
   (Load `quota_state.json`), kind supported (Match).
3. **Select** — among authorized providers in the lowest sufficient tier: max
   remaining-quota headroom; ties → lowest latency observed (Observe history).
   Zero candidates → escalate one tier, re-Authorize.
4. **Schedule** — all of a tier exhausted → Schedule retry after quota reset;
   daily cron recalibrates the free-tier availability list (§1.5 requirement) by
   probing each provider with a 1-token call and rewriting `quota_state.json`.
5. **Record** — every cloud run emits the same receipts/pathways schema as local
   runs (§1.5 requirement) + Newton/POPW energy accounting hooks (Phase 9).

## 4. Retry & fallback policy (v1 defaults, all PROPOSED)

- 429/rate-limit → mark provider cooled-down ( Observe: cooldown = retry-after
  header if present, else 60 s), re-Select immediately.
- 5xx/timeout (2 attempts) → next provider in tier; tier empty → escalate.
- Content refused / answer quality < gauge V-standards → completion gauge
  REQUEUE at higher tier (ties into docs/completion_gauge_v1.md).
- Local Ollama is always_last_in_tier 0: free, but only after cloud free tiers —
  keeps the A15 battery out of the hot path when free quota exists.

## 5. Deliberately deferred

- Cost ledger + POPW integration (Phase 9 does the wiring).
- Embedding-model versioning for the hash-keyed cache (§3 embedding decision) —
  cascade v1 treats embeddings as just another `kinds` capability.
- Multi-node fleet coordination of quota (each node keeps its own
  `quota_state.json`; merge is a v2 question).
