# Completion Gauge v1 — Decide+Verify over receipt state (manifest §3, §1.7)

Status: PROPOSED (design sealed 2026-11-09, not implemented). Structural home:
the gauge is not a component — it is the `Decide` + `Verify` primitives applied to
the receipt stream at each loop boundary (§1.7 canonical pipeline).

## 1. Inputs

- `receipts_this_loop`: the sub-receipts emitted by every processor that ran in
  loop iteration N. Each sub-receipt already carries (per §1.3):
  claims + citations (sha256), time/energy used, and the always-present
  "what clarifying question would have helped me?" field.
- `loop_history`: the gauge verdicts + gain measurements of previous iterations.

## 2. Information gain (definition — this is the threshold §3 left TBD)

`gain(N) = |new facts ∪ new citations ∪ new pathway nodes|` contributed by
iteration N, counted as:

- **new facts**: answer-core statements absent from loop N-1's core
  (dedup on normalized statement text);
- **new citations**: sha256 cells cited now that were never cited before in this
  pathway;
- **new pathway nodes**: cached-pathway tables created this iteration (§1.4).

`gain = 0` (the proposed ε) means the loop added none of the three. No fuzzy
similarity in v1 — exact/dedup counting only, cheap and auditable.

## 3. Verdict function

```
function completion_gauge(loop N) -> {COMPLETE, CONTINUE, REQUEUE, HALT}

  # --- Verify primitive -------------------------------------------------
  V1  citations_resolve:   every cited sha256 exists as a registry cell (Load+Match)
  V2  calcs_recheck:       every numeric claim recomputes (Verify)
  V3  no_new_questions:    zero open clarifying questions in any sub-receipt   # (a)
  V4  budget_ok:           elapsed <= hard ceiling (2x soft budget, §3)

  # --- Decide primitive -------------------------------------------------
  if not V4:                          return HALT("ceiling")        # trap-emit receipt
  if not V1 or not V2:                return REQUEUE("unverified claim")
  if not V3:                          return REQUEUE(newest_question)   # reactive re-queue
  if gain(N) == 0 and gain(N-1) == 0: return COMPLETE               # (c) 2x zero-gain
  return CONTINUE
```

- **REQUEUE** feeds the question back through staging (merged option, §1.3:
  reactive re-queue AND proactive capture, both, always).
- **COMPLETE** requires the conjunction: verified, no open questions, AND two
  consecutive zero-gain iterations. Two, not one — one quiet loop may mean the
  processor stalled; two means the vein is exhausted.
- **HALT** is the hard-ceiling kill §3 worried about: because it fires at the
  loop boundary (not mid-processor), receipts and thermo data survive.

## 4. Receipt of the gauge itself

The gauge emits its own receipt (it is a processor too): verdict, which V-failed,
gain(N) and gain(N-1) component counts, elapsed vs budget. Schema identical to
every other receipt so the pathway tables store it unchanged (fractal 3-3-3).

## 5. Deliberately deferred

- Fuzzy gain (semantic novelty) — v2; only if exact-count gain proves too twitchy.
- Per-tier gain thresholds (a frontier-model loop may warrant ε>0) — after the
  cascade router (§1.5) exists to bias against.
- Interaction with the completion "gauge judges full-capability answer" language in
  §1.3: v1 treats full-capability == V1..V3 all pass; revisit when processors
  declare capability profiles.
