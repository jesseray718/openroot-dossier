#!/usr/bin/env bash
# hash_keeper_v1.sh — Auto Dossier Phase 1: incremental hash-registry keeper.
#
# WHAT IT DOES
#   Walks each --scan-root, stats every regular file, and appends registry rows
#   for files that are NEW or CHANGED (size+mtime differ from the newest row
#   already in the registry for that path). Unchanged files are skipped with no
#   rehash and no append. Append-only: existing lines are never edited; the
#   consolidator resolves newest-wins per path.
#
# REGISTRY FORMAT (one '#'-header line, then TSV rows, tab-separated):
#   # hash_registry_v1  sha256  size  mtime_epoch  path  root  host  scan_id
#   <64-hex> <TAB> <bytes> <TAB> <epoch> <TAB> <abs path> <TAB> <root> <TAB> <host> <TAB> <scan_id>
#
#   scan_id = HK-<UTCtimestamp>.<ms>Z-<host> -> lexicographic order == chronological,
#   so "newest" is just the greatest scan_id for a path.
#
# LABELS: TESTED = sandbox fixture (see GATE_RECEIPT.txt in the delivery bundle).
#         Default exclude list = PROPOSED (from fleet-census incidents) until
#         verified on node.
#
# USAGE:
#   hash_keeper_v1.sh --scan-root DIR [--scan-root DIR ...]
#                     [--registry FILE] [--exclude PATTERN] [--parallel N]
#                     [--budget SECONDS] [--progress N] [--dry-run]
#                     [--no-default-excludes] [--receipt FILE]
#
# EXIT CLASSES (in receipt): COMPLETE | BUDGET | INTERRUPTED | FATAL
set -u -o pipefail

TOOL="hash_keeper_v1"
VERSION="1"

usage() { awk 'NR>1 && /^#/{sub(/^# ?/,"");print} /^$/{exit}' "$0"; exit "${1:-0}"; }

# ---------------------------------------------------------------- arguments --
ROOTS=()
EXCLUDES_USER=()
REGISTRY=""
PARALLEL=1
BUDGET=0          # 0 = no budget (run to completion)
PROGRESS=20000    # stderr heartbeat every N files seen; 0 = off
DRY=0
NODEFAULT=0
RECEIPT=""

while [ $# -gt 0 ]; do
  case "$1" in
    --scan-root)          ROOTS+=("${2:?--scan-root needs a value}"); shift 2 ;;
    --registry)           REGISTRY="$2"; shift 2 ;;
    --exclude)            EXCLUDES_USER+=("${2:?--exclude needs a value}"); shift 2 ;;
    --parallel)           PARALLEL="${2:?}"; shift 2 ;;
    --budget)             BUDGET="${2:?}"; shift 2 ;;
    --progress)           PROGRESS="${2:?}"; shift 2 ;;
    --dry-run)            DRY=1; shift ;;
    --no-default-excludes) NODEFAULT=1; shift ;;
    --receipt)            RECEIPT="$2"; shift 2 ;;
    -h|--help)            usage 0 ;;
    *) echo "FATAL: unknown argument: $1" >&2; usage 1 ;;
  esac
done

[ "${#ROOTS[@]}" -eq 0 ] && { echo "FATAL: at least one --scan-root is required" >&2; exit 2; }

HOST="$(hostname 2>/dev/null || echo unknown-host)"
[ -n "$REGISTRY" ] || REGISTRY="$PWD/hash_registry_${HOST}.tsv"
# scan_id MUST be unique per run and lexicographically ordered: two keeper runs
# in the same wall-clock second would otherwise collide on recency (newest-wins
# joins compare scan_id strings). Milliseconds when date supports %3N (GNU
# coreutils — both fleet nodes); pid fallback otherwise.
_sid="$(date -u +%Y%m%dT%H%M%S.%3N 2>/dev/null || true)"
case "$_sid" in
  [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]T[0-9][0-9][0-9][0-9][0-9][0-9].[0-9][0-9][0-9]) : ;;
  *) _sid="$(date -u +%Y%m%dT%H%M%S).$$" ;;
esac
SCAN_ID="HK-${_sid}Z-${HOST}"
mkdir -p -- "$(dirname -- "$REGISTRY")" || { echo "FATAL: cannot create registry dir" >&2; exit 2; }
[ -n "$RECEIPT" ] || RECEIPT="${REGISTRY}.receipts.log"

# Validate + absolutize roots
i=0
for r in "${ROOTS[@]}"; do
  [ -d "$r" ] || { echo "FATAL: scan-root is not a directory: $r" >&2; exit 2; }
  ROOTS[$i]="$(cd -- "$r" && pwd)"
  i=$((i+1))
done

# ------------------------------------------------------------- receipt core --
T0=$SECONDS
SEEN=0; HASHED=0; SKIPPED=0; ERR_STAT=0; ERR_ODD=0; ERR_HASH=0; ERR_FIND=0
BYTES=0
STOPCLASS="COMPLETE"

emit_receipt() {
  local rc="${1:-0}"
  local el=$(( SECONDS - T0 ))
  local rows
  rows="$(grep -c -v '^#' "$REGISTRY" 2>/dev/null || true)"
  local block
  block=$(printf 'RECEIPT %s tool=%s v%s\nstatus=%s rc=%s elapsed_s=%d budget_s=%s\nroots=%s\nfiles_seen=%d hashed=%d skipped=%d bytes_hashed=%d\nerrors: stat=%d odd_path=%d hash=%d find=%d\nregistry=%s registry_rows=%s\n' \
    "$SCAN_ID" "$TOOL" "$VERSION" "$STOPCLASS" "$rc" "$el" "$BUDGET" \
    "${ROOTS[*]}" "$SEEN" "$HASHED" "$SKIPPED" "$BYTES" \
    "$ERR_STAT" "$ERR_ODD" "$ERR_HASH" "$ERR_FIND" "$REGISTRY" "${rows:-0}")
  printf '%s\n' "$block" >&2
  printf '%s\n' "$block" >> "$RECEIPT" 2>/dev/null || true
}
cleanup() { rm -rf -- "$TMPD" 2>/dev/null || true; }
trap 'rc=$?; cleanup; emit_receipt "$rc"' EXIT
trap 'STOPCLASS=INTERRUPTED; exit 130' INT TERM

# ----------------------------------------------------------------- excludes --
EXCLUDES=()
if [ "$NODEFAULT" -eq 0 ]; then
  # PROPOSED defaults — learned from census incidents (manifest §2, §7 2026-11-08(a)):
  #   volumetric-project/*      : quarantined in fleet census after crash
  #   proc|sys|dev|run          : kernel/ephemeral trees, never dossier content
  #   Android/data, Android/obb : Android scoped-storage blind spots for Termux
  #   lost+found                : fs recovery junk
  for p in 'proc/*' 'sys/*' 'dev/*' 'run/*' 'lost+found/*' \
           'volumetric-project/*' 'Android/data/*' 'Android/obb/*'; do
    EXCLUDES+=("$p")
  done
fi
EXCLUDES+=(${EXCLUDES_USER[@]+"${EXCLUDES_USER[@]}"})

# ------------------------------------------------- load skip index (pass 0) --
TMPD="$(mktemp -d "${TMPDIR:-/tmp}/hashkeeper.XXXXXX")" || exit 3
IDXTMP="$TMPD/index.tsv"
# registry -> "path<TAB>size<TAB>mtime" (newest row per path irrelevant here:
# any stored (size,mtime) that matches means unchanged, since content changes
# always change one of the two — mtime granularity caveat noted in RUNBOOK).
grep -h -v '^#' -- "$REGISTRY" 2>/dev/null \
  | awk -F'\t' 'NF>=7 && $4!="" { print $4 "\t" $2 "\t" $3 }' > "$IDXTMP" || true

declare -A IDX=()
while IFS=$'\t' read -r p s m; do IDX["$p"]="$s|$m"; done < "$IDXTMP"

# If registry is brand new, write the header line once.
[ -s "$REGISTRY" ] || \
  printf '# hash_registry_v1\tsha256\tsize\tmtime_epoch\tpath\troot\thost\tscan_id\n' >> "$REGISTRY"

# ------------------------------------------------------------- main per-root --
for ROOT in "${ROOTS[@]}"; do

  # Build find expression with pruned excludes (patterns anchored at this root
  # unless given as absolute paths).
  EXPR=()
  first=1
  for pat in "${EXCLUDES[@]}"; do
    [ -n "$pat" ] || continue
    p="$pat"
    case "$p" in /*) : ;; *) p="$ROOT/$p" ;; esac
    if [ "$first" -eq 1 ]; then EXPR=( '(' -path "$p" ); first=0
    else EXPR+=( -o -path "$p" ); fi
  done

  TAG="$(printf '%s' "$ROOT" | sha256sum | cut -c1-10)"
  PATHS="$TMPD/paths.$TAG"; FINDERR="$TMPD/finderr.$TAG"
  if [ "$first" -eq 0 ]; then
    find "$ROOT" "${EXPR[@]}" ')' -prune -o -type f -print0 \
      > "$PATHS" 2> "$FINDERR" || true
  else
    find "$ROOT" -type f -print0 > "$PATHS" 2> "$FINDERR" || true
  fi
  nfinderr="$(wc -l < "$FINDERR" 2>/dev/null || echo 0)"
  ERR_FIND=$(( ERR_FIND + nfinderr ))

  # ---- pass A: classify (stat + skip-check); collect needs
  NEEDS="$TMPD/needs.$TAG"; NEEDSTATS="$TMPD/needstats.$TAG"
  : > "$NEEDS"; : > "$NEEDSTATS"
  while IFS= read -r -d '' f; do
    SEEN=$(( SEEN + 1 ))
    case "$f" in
      *$'\t'*|*$'\n'*) ERR_ODD=$(( ERR_ODD + 1 )); continue ;;
    esac
    if st="$(stat -c '%s %Y' -- "$f" 2>/dev/null)"; then :; else
      ERR_STAT=$(( ERR_STAT + 1 )); continue
    fi
    size="${st%% *}"; mtime="${st##* }"
    prev="${IDX[$f]-}"
    if [ -n "$prev" ] && [ "$prev" = "$size|$mtime" ]; then
      SKIPPED=$(( SKIPPED + 1 ))
      continue
    fi
    printf '%s\0' "$f" >> "$NEEDS"
    printf '%s\t%s\t%s\n' "$f" "$size" "$mtime" >> "$NEEDSTATS"
    if [ "$PROGRESS" -gt 0 ] && [ $(( SEEN % PROGRESS )) -eq 0 ]; then
      printf 'PROGRESS %s seen=%d hashed=%d skipped=%d errors=%d elapsed=%ds\n' \
        "$SCAN_ID" "$SEEN" "$HASHED" "$SKIPPED" \
        $(( ERR_STAT + ERR_ODD + ERR_HASH )) "$(( SECONDS - T0 ))" >&2
    fi
    if [ "$BUDGET" -gt 0 ] && [ $(( SECONDS - T0 )) -ge "$BUDGET" ]; then
      STOPCLASS="BUDGET"
      break
    fi
  done < "$PATHS"

  if [ "$DRY" -eq 1 ]; then
    printf 'DRY-RUN %s root=%s would_hash=%d (skipped=%d errors=%d)\n' \
      "$SCAN_ID" "$ROOT" "$(wc -l < "$NEEDSTATS" 2>/dev/null || echo 0)" \
      "$SKIPPED" $(( ERR_STAT + ERR_ODD + ERR_FIND )) >&2
    continue
  fi

  # ---- pass B: hash the needs (parallel), normalize, join stats, append rows
  if [ -s "$NEEDS" ]; then
    HASHOUT="$TMPD/hashout.$TAG"; HASHERR="$TMPD/hasherr.$TAG"
    xargs -0 -r -P "$PARALLEL" -n 1 sha256sum -- \
      < "$NEEDS" > "$HASHOUT" 2> "$HASHERR" || true
    ERR_HASH=$(( ERR_HASH + $(grep -c . "$HASHERR" 2>/dev/null || true) ))

    # normalize sha256sum output -> "sha<TAB>path"
    # GNU escapes filenames containing backslash/newline: line is prefixed
    # with '\' and backslashes in the name are doubled. Newline names were
    # already refused in pass A, so only backslash-doubling can appear.
    NORM="$TMPD/norm.$TAG"
    while IFS= read -r line; do
      [ -n "$line" ] || continue
      esc=0
      case "$line" in
        \\*) esc=1; line="${line#\\}" ;;
      esac
      hash="${line%% *}"
      rest="${line#* }"
      path="${rest# }"
      if [ "$esc" -eq 1 ]; then path="${path//\\\\/\\}"; fi
      [ -n "$hash" ] && [ -n "$path" ] && printf '%s\t%s\n' "$hash" "$path" >> "$NORM"
    done < "$HASHOUT"

    ROWS="$TMPD/rows.$TAG"
    if [ -s "$NORM" ]; then
      awk -F'\t' -v ROOT="$ROOT" -v HOST="$HOST" -v SCANID="$SCAN_ID" '
        NR==FNR { sha[$2]=$1; next }
        ($1 in sha) { printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n", sha[$1], $2, $3, $1, ROOT, HOST, SCANID }
      ' "$NORM" "$NEEDSTATS" > "$ROWS"
    else
      : > "$ROWS"
    fi

    if [ -s "$ROWS" ]; then
      cat -- "$ROWS" >> "$REGISTRY"
      HASHED=$(( HASHED + $(wc -l < "$ROWS") ))
      BYTES=$(( BYTES + $(awk -F'\t' '{s+=$2} END{print s+0}' "$ROWS") ))
      while IFS=$'\t' read -r _sha size _mtime p _r _h _s; do
        IDX["$p"]="$size|$mtime"
      done < "$ROWS"
    fi
  fi

  # Budget stop = clean stop for the WHOLE run; rerun resumes safely.
  if [ "$STOPCLASS" = "BUDGET" ]; then break; fi

done   # per-root loop

# row-count fix for HASHED when DRY (never hashed)
[ "$DRY" -eq 1 ] && HASHED=0
exit 0
