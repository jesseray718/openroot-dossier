# RUNBOOK — hash registry v1 (Auto Dossier Phase 1)

Owner: Jesse · Authored: 2026-11-09 in a Z.ai sandbox window (OFF-NODE) · Rev: 2 (2026-11-09: §4 GitHub release rail added, release_push_v1.sh; §0/§1/§2 unchanged for the registry scripts)

**Provenance labels.** Everything in this bundle was authored and fixture-tested in the
Z.ai sandbox only: `TESTED (sandbox fixture)` — see `GATE_RECEIPT.txt`. Nothing here has
touched A15 or OptiPlex: every fleet run is `PROPOSED` until its on-node receipt exists.
This window cannot see your nodes and makes no fleet claims.

**Files.**

| file | role |
|---|---|
| `hash_keeper_v1.sh` | incremental hasher → append-only registry TSV |
| `hash_registry_consolidate_v1.sh` | validate + merge registries, newest-wins, dup groups, reclaimable bytes |
| `registry_tsv_to_sqlite_v1.py` | TSV → SQLite bridge (Phase-4 preview; stdlib only) |
| `release_push_v1.sh` | release rail: gate → BUILD_STATUS → commit → tag → push → `gh release` (§4) |
| `SHA256SUMS.txt` | `sha256sum -c` gate list (rev 2: 4 payload files) |
| `GATE_RECEIPT.txt` | sandbox gates + fixture transcript (Phase-1 scripts) |
| `GATE_RECEIPT_RELEASE_V1.txt` | sandbox gates + behavior tests (release rail) |
| `docs/completion_gauge_v1.md`, `docs/cloud_cascade_v1.md` | §3 / §1.5 design specs |

**Registry row schema (sealed here, v1).**

```
sha256 <TAB> size <TAB> mtime_epoch <TAB> path <TAB> root <TAB> host <TAB> scan_id
```

Append-only. Never edit or delete lines. `scan_id = HK-<UTC ts>.<ms>Z-<host>` is
fixed-width, so lexicographic max == newest. Newest row per path = current truth.

---

## 0. GATE ON EVERY NODE BEFORE FIRST RUN (doctrine §0.2)

```bash
sha256sum -c SHA256SUMS.txt                                # expect: OK × 4 files
bash -n hash_keeper_v1.sh                    && echo GATE_KEEPER_OK
bash -n hash_registry_consolidate_v1.sh      && echo GATE_CONSOL_OK
python3 -m py_compile registry_tsv_to_sqlite_v1.py && echo GATE_LOADER_OK
bash -n release_push_v1.sh                   && echo GATE_RELEASE_OK
```

Any mismatch or syntax error → do not run; report back with the diff.

## 1. A15 TERMUX  (prompt `localhost:~$`)

```bash
mkdir -p ~/hash_registry
termux-wake-lock     # long first pass; release after

# First full pass — both roots, per Phase 1 decision (manifest §4, A15 line):
bash hash_keeper_v1.sh \
  --scan-root "$HOME" \
  --scan-root /storage/emulated/0 \
  --registry "$HOME/hash_registry/registry_a15.tsv" \
  --parallel 2 --progress 10000

# Bounded-loop variant (soft budget, clean stop, rerun to resume):
bash hash_keeper_v1.sh --scan-root "$HOME" --scan-root /storage/emulated/0 \
  --registry "$HOME/hash_registry/registry_a15.tsv" --budget 1800

# Inspect without writing:
bash hash_keeper_v1.sh --scan-root "$HOME" --dry-run --registry /tmp/dry.tsv

# Consolidate + load:
bash hash_registry_consolidate_v1.sh \
  --input "$HOME/hash_registry/registry_a15.tsv" \
  --outdir "$HOME/hash_registry/consolidated_a15"
python3 registry_tsv_to_sqlite_v1.py \
  --input "$HOME/hash_registry/consolidated_a15/registry_consolidated.tsv" \
  --db "$HOME/hash_registry/registry_a15.sqlite3"
termux-wake-unlock
```

Expect the first pass to take on the order of the census (≈249k files) — the keeper
rehashes only new/changed files on every later run (skip index = the registry itself).

## 2. OPTIPLEX  (prompt `optiplex3060:~/openroot$`)

Do NOT contend with `fleet_census`. Check first (manifest §4):

```bash
pgrep -af '[f]leet_census' && echo CENSUS_ALIVE || echo CENSUS_DONE_OR_DEAD
```

If ALIVE: wait, or scan a disjoint tree. When clear:

```bash
mkdir -p ~/hash_registry
nice -n 19 bash hash_keeper_v1.sh \
  --scan-root "$HOME" \
  --registry "$HOME/hash_registry/registry_optiplex.tsv" \
  --parallel 8 --progress 50000

bash hash_registry_consolidate_v1.sh \
  --input "$HOME/hash_registry/registry_optiplex.tsv" \
  --outdir "$HOME/hash_registry/consolidated_optiplex"
python3 registry_tsv_to_sqlite_v1.py \
  --input "$HOME/hash_registry/consolidated_optiplex/registry_consolidated.tsv" \
  --db "$HOME/hash_registry/registry_optiplex.sqlite3" --vacuum
```

## 3. CROSS-NODE MERGE (one node holds both TSVs)

```bash
bash hash_registry_consolidate_v1.sh \
  --input registry_a15.tsv --input registry_optiplex.tsv \
  --outdir ./consolidated_fleet
python3 registry_tsv_to_sqlite_v1.py \
  --input ./consolidated_fleet/registry_consolidated.tsv \
  --db ./registry_fleet.sqlite3
# Dup report to eyeball: consolidated_fleet/duplicate_groups.tsv
```

## 4. GITHUB RELEASE RAIL  (`release_push_v1.sh` — the one-command publisher)

Drop `release_push_v1.sh` (ideally with the whole bundle) anywhere on the node,
then run it. It reads ONLY its own directory: stages every `*.sh *.py *.md`
(+ `docs/*.md`) into the repo dir, gates them (`bash -n` / `py_compile`), writes
`BUILD_STATUS.md` + `GATE_RECEIPT.txt`, commits both, tags, pushes, and cuts the
GitHub release with every file as a release asset. Requires `gh auth login` once.

```bash
# OptiPlex (gh authenticated) — ready-to-run as-is:
bash release_push_v1.sh                        # private repo openroot-dossier

# Variants:
bash release_push_v1.sh --repo my-name --public --tag v0.1.0
bash release_push_v1.sh --repo-dir "$HOME/openroot/dossier" --no-push   # local only
bash release_push_v1.sh --dry-run              # print plan; gates run for real

# A15 / any node without gh — gate + build status + local git release:
bash release_push_v1.sh --no-push
```

What it writes into the repo dir: `GATE_RECEIPT.txt`, `BUILD_STATUS.md`,
`RELEASE_NOTES.md`, `RELEASE_RECEIPT.txt`, `WORK_LOG.md` (append-only — one line
per release; paste that line into master manifest §7), `.gitignore`, `dist/`.
Tag default is `v<UTCdate>-<shortsha>`, auto-uniquified `-r2` `-r3` on rerun.
A rerun never re-creates the repo or rewrites history: it commits a fresh build
status, adds a new tag, and updates the release assets (`--clobber`).
Defaults: repo dir `$HOME/openroot/dossier`, repo name `openroot-dossier`
(env override `GH_REPO_NAME`), visibility PRIVATE (flip with `--public`).

---

## Notes, gotchas, decisions baked into v1

- **Default excludes (PROPOSED — tuned from census incidents, §2/§7):**
  `proc/* sys/* dev/* run/* lost+found/* volumetric-project/* Android/data/* Android/obb/*`.
  Patterns are anchored under each `--scan-root` unless given as absolute paths.
  Override wholesale with `--no-default-excludes` plus your own `--exclude` flags.
- **Odd paths refused:** any path containing TAB or NEWLINE is counted (`odd_path` in
  the receipt) and skipped, not hashed. Backslash-containing names ARE handled —
  GNU sha256sum escaping is decoded (fixture-tested).
- **Skip granularity = size + mtime-seconds.** A same-size change within the same
  second is invisible to v1. Accept for files; flag anything suspicious and a v2 can
  add content-probe re-checks.
- **Budget stop is clean.** `--budget SECONDS` soft-stops between files, emits a
  receipt with `status=BUDGET`; rerunning resumes (already-indexed files skip).
- **The consolidator refuses headerless input on purpose.** The 446 MB
  `census_manifest.tsv` is a different format and is NOT a v1 input — your census
  already produced duplicate stats; converting it is a v2 decision.
- **RAM profile.** Keeper index ≈ rows × ~120 B in bash memory (249k rows ≈ 40 MB on
  A15; fine). Consolidator is streaming (sort + awk), constant memory — safe at
  fleet scale. Loader batches at 20k rows/txn (tune with `--batch`).
- **SQLite needs ≥ 3.24.0** for the newest-wins upsert (loader checks and refuses
  cleanly). Sandbox ran 3.53.1; Termux/OptiPlex both ship newer than 3.24.
- **`GROUPS` lesson (2026-11-09):** never name a bash variable `GROUPS` — it is a
  special built-in array; assignments are silently discarded. Now documented in the
  consolidator source next to the fix.
